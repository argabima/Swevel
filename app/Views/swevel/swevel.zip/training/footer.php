<section id="footer-training">
    <div class="container">
        <div class="text-center p-4 text-purple-100 fw-bold">
            Swevel | <?= date('Y') ?>
        </div>
    </div>
</section>
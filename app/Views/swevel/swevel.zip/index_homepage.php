<?= $this->extend('layout/template'); ?>
<?= $this->section('content'); ?>
<?= $this->include('swevel/navbar'); ?>
<?= $this->include('swevel/homepage/about-us'); ?>
<?= $this->include('swevel/homepage/product_service'); ?>
<?= $this->include('swevel/homepage/portofolio'); ?>
<?= $this->include('swevel/homepage/milestone'); ?>
<?= $this->include('swevel/homepage/article_homepage'); ?>
<?= $this->include('swevel/homepage/team'); ?>
<?= $this->include('swevel/homepage/client'); ?>
<?= $this->include('swevel/homepage/contact'); ?>
<?= $this->include('swevel/homepage/footer'); ?>

<?= $this->endSection(); ?>